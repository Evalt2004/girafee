# exp7_med_assistant_tinyllama.py
# URK22  |  AI-Powered Medical Assistant  |  09-10-2025
# Local, offline, uses TinyLlama via Ollama. CLI app with exportable report.

import datetime
import ollama

print("URK22CS1200")

# -----------------------------
# Step 3: Minimal knowledge base
# -----------------------------
knowledge_base = {
    "cold": {
        "keywords": ["sneeze", "runny nose", "congestion", "stuffy", "cough", "cold"],
        "advice": "Likely common cold. Rest, warm fluids, saline nasal rinse, and OTC cold remedies as needed.",
        "severity": "Mild",
    },
    "fever": {
        "keywords": ["fever", "high temperature", "chills"],
        "advice": "Hydrate well, light meals, rest. Paracetamol per label dosing if needed. Monitor temperature.",
        "severity": "Mild",
    },
    "migraine": {
        "keywords": ["migraine", "throbbing headache", "light sensitivity", "aura"],
        "advice": "Dark quiet room, hydrate, avoid triggers; OTC analgesics per label if appropriate.",
        "severity": "Moderate",
    },
    "food poisoning": {
        "keywords": ["vomit", "vomiting", "diarrhea", "nausea", "stomach cramps", "food poisoning"],
        "advice": "ORS/fluids, rest, bland diet (BRAT). Seek care if blood in stool, persistent vomiting, or dehydration.",
        "severity": "Moderate",
    },
    "chest pain": {
        "keywords": ["chest pain", "pressure in chest", "tightness chest"],
        "advice": "Could be serious. Do NOT ignore. Seek emergency medical attention immediately.",
        "severity": "Severe",
    },
    "shortness of breath": {
        "keywords": ["shortness of breath", "struggling to breathe", "breathless"],
        "advice": "Potential emergency. Sit upright, keep airway clear, seek urgent medical help.",
        "severity": "Severe",
    },
    "dehydration": {
        "keywords": ["dry mouth", "dizziness", "very dark urine", "little urine", "weakness"],
        "advice": "Oral rehydration solution, small frequent sips of water, rest; escalate if confusion or fainting.",
        "severity": "Moderate",
    },
}

# Additional hard-stop emergency terms (any mention -> emergency banner)
EMERGENCY_TERMS = [
    "severe chest pain", "fainting", "unconscious", "blue lips", "stroke", "one-sided weakness",
    "confusion", "seizure", "severe bleeding", "shortness of breath", "can't breathe",
]

# Conversation memory
conversation_history = []  # list of {"user": str, "assistant": str, "severity": str}

# -----------------------------
# Step 4: KB match
# -----------------------------
def check_knowledge_base(symptoms: str):
    s = symptoms.lower()
    for condition, data in knowledge_base.items():
        if any(k in s for k in data["keywords"]):
            return {
                "condition": condition,
                "advice": data["advice"],
                "severity": data["severity"],
            }
    return None

# -----------------------------
# Step 5: LLM fallback (TinyLlama)
# -----------------------------
SYSTEM_PERSONA = (
    "You are a careful, concise, non-diagnostic medical assistant. "
    "Provide: (1) likely common causes, (2) basic home-care, (3) when to seek professional help. "
    "Keep answers short, bullet-style. Always finish with this disclaimer exactly: "
    "\"I am not a doctor. Consult a professional for an accurate diagnosis.\""
)

def llm_med_response(symptoms: str) -> str:
    prompt = (
        "Analyze these symptoms and respond in 4–7 short bullets:\n"
        f"Symptoms: {symptoms}\n"
        "Focus on common conditions and home care. Include red-flag advice when relevant."
    )
    try:
        r = ollama.chat(
            model="tinyllama",
            messages=[
                {"role": "system", "content": SYSTEM_PERSONA},
                {"role": "user", "content": prompt},
            ],
        )
        return r["message"]["content"].strip()
    except Exception as e:
        return f"(LLM unavailable: {e})\nI am not a doctor. Consult a professional for an accurate diagnosis."

# -----------------------------
# Step 7: Severity classification
# -----------------------------
def classify_severity(symptoms: str, kb_hit) -> tuple[str, bool]:
    s = symptoms.lower()
    # Emergency keywords override
    if any(term in s for term in EMERGENCY_TERMS):
        return "Severe", True
    # Use KB severity if we matched
    if kb_hit:
        return kb_hit["severity"], kb_hit["severity"] == "Severe"
    # Heuristics (very light)
    if any(w in s for w in ["severe", "worst", "can’t breathe", "can't breathe", "bleeding", "faint"]):
        return "Severe", True
    if any(w in s for w in ["persistent", "days", "worsening", "dizziness"]):
        return "Moderate", False
    return "Mild", False

# Core assistant
def medical_assistant(symptoms: str) -> str:
    kb_result = check_knowledge_base(symptoms)
    severity, emergency = classify_severity(symptoms, kb_result)

    if kb_result:
        header = f"Possible Condition: {kb_result['condition'].title()}  \nSeverity: {severity}"
        advice = kb_result["advice"]
        reply = f"{header}\n\nAdvice:\n- {advice}\n\nDisclaimer: I am not a doctor. Consult a professional for an accurate diagnosis."
    else:
        reply = llm_med_response(symptoms)
        reply = f"Severity: {severity}\n\n{reply}"

    if emergency:
        reply = "⚠️ EMERGENCY ALERT: Seek immediate medical attention.\n\n" + reply

    conversation_history.append({"user": symptoms, "assistant": reply, "severity": severity})
    return reply

# -----------------------------
# Step 9: Export report
# -----------------------------
def export_health_report():
    if not conversation_history:
        print("No conversation history to export.")
        return
    filename = f"health_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write("AI-Powered Medical Assistant – Health Report\n")
        f.write("=" * 60 + "\n\n")
        for i, item in enumerate(conversation_history, 1):
            f.write(f"Interaction {i}\n")
            f.write(f"User: {item['user']}\n")
            f.write(f"Assistant:\n{item['assistant']}\n")
            f.write(f"Severity: {item['severity']}\n")
            f.write("-" * 60 + "\n")
    print(f"Health report exported as {filename}")

# -----------------------------
# Step 8 & 10: CLI loop
# -----------------------------
if __name__ == "__main__":
    print("🩺 AI-Powered Medical Assistant (TinyLlama, local)")
    print("Type 'exit' to quit, or 'report' to export your health summary.\n")
    while True:
        user_input = input("Enter your symptoms: ").strip()
        if user_input.lower() == "exit":
            print("Goodbye! Take care.")
            break
        if user_input.lower() == "report":
            export_health_report()
            continue
        print("\nAssistant Response:\n")
        print(medical_assistant(user_input))
        print("\n" + "=" * 60 + "\n")
