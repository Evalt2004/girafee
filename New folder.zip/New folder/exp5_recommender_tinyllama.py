# exp5_recommender_tinyllama.py
# Personalized recommender using TF-IDF + TinyLlama (Ollama) + Gradio
# Dataset embedded for speed.

import json
import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import gradio as gr
import ollama

print("URK22CS1200")  # as requested in your sample

# ----------------- Step 1: Tiny inline dataset -----------------
items = [
    {"title": "Interstellar",
     "description": "A sci-fi film about space exploration, love, and survival across galaxies.",
     "genres": "Sci-Fi, Drama, Adventure"},
    {"title": "Inception",
     "description": "A master thief who enters dreams to steal secrets faces a final job about planting an idea.",
     "genres": "Sci-Fi, Action, Thriller"},
    {"title": "The Shawshank Redemption",
     "description": "A banker forms a profound friendship in prison and fights for hope and freedom.",
     "genres": "Drama"},
    {"title": "Her",
     "description": "A thoughtful romance between a writer and an AI operating system about intimacy and identity.",
     "genres": "Romance, Drama, Sci-Fi"},
    {"title": "Arrival",
     "description": "A linguist deciphers alien language while confronting memory, time, and loss.",
     "genres": "Sci-Fi, Mystery, Drama"},
    {"title": "Good Will Hunting",
     "description": "A gifted janitor wrestles with trauma, genius, friendship, and purpose.",
     "genres": "Drama"},
]

df = pd.DataFrame(items)
df["combined"] = (df["title"] + " " + df["description"] + " " + df["genres"]).str.lower()

# ----------------- Step 2: Vectorize item descriptions -----------------
vectorizer = TfidfVectorizer(stop_words="english")
item_vectors = vectorizer.fit_transform(df["combined"])

# ----------------- Step 3: Parse user prefs with TinyLlama -----------------
def parse_preferences_with_ollama(user_text: str) -> dict:
    """
    Ask TinyLlama to extract weighted keywords. Expect JSON only.
    Fallbacks to empty dict if parsing fails.
    """
    prompt = (
        "Extract weighted keywords (0 to 1) from this user preference text.\n"
        "Respond with ONLY a compact JSON object (no extra words), keys lowercase.\n"
        f'Text: "{user_text}"\n'
        'Example output: {"sci-fi": 0.9, "drama": 0.7, "friendship": 0.6}\n'
        "JSON:"
    )
    try:
        r = ollama.generate(model="tinyllama", prompt=prompt)
        raw = r.get("response", "").strip()
        # keep only the first {...} block to avoid chatter
        m = re.search(r"\{.*\}", raw, flags=re.S)
        if m:
            raw = m.group(0)
        weights = json.loads(raw)
        # sanitize values to 0..1 floats, keys to lowercase
        clean = {}
        for k, v in weights.items():
            try:
                val = float(v)
            except Exception:
                # try to coerce common string numbers like "0.8"
                try:
                    val = float(str(v).strip())
                except Exception:
                    continue
            clean[str(k).lower()] = max(0.0, min(1.0, val))
        return clean
    except Exception:
        return {}

# ----------------- Step 4: Compute similarity -----------------
def recommend_items(user_text: str, top_n: int = 3):
    prefs = parse_preferences_with_ollama(user_text)
    if prefs:
        # Build a weighted query string by repeating words ~ weight*10
        user_keywords = " ".join(
            (word + " ") * max(1, int(weight * 10)) for word, weight in prefs.items()
        ).strip()
    else:
        # Fallback: use raw text
        user_keywords = user_text

    user_vec = vectorizer.transform([user_keywords.lower()])
    sims = cosine_similarity(user_vec, item_vectors).ravel()
    top_idx = sims.argsort()[-top_n:][::-1]
    recs = df.iloc[top_idx][["title", "genres", "description"]].copy()
    recs["score"] = [round(float(sims[i]), 3) for i in top_idx]
    return recs

# ----------------- Step 5: Minimal Gradio UI -----------------
def gradio_recommender(user_input: str):
    recs = recommend_items(user_input, top_n=3)
    lines = []
    for _, row in recs.iterrows():
        lines.append(
            f"**{row['title']}**  \n"
            f"*{row['genres']}*  \n"
            f"{row['description']}  \n"
            f"_score: {row['score']}_"
        )
    return "\n\n---\n\n".join(lines) if len(lines) else "No recommendations found."

ui = gr.Interface(
    fn=gradio_recommender,
    inputs=gr.Textbox(label="Describe what you like",
                      placeholder="e.g., I enjoy thoughtful sci-fi with deep characters"),
    outputs=gr.Markdown(label="Top Recommendations"),
    title="Personalized Recommender (TinyLlama + TF-IDF)",
    description="Type your preference in natural language. We extract weighted keywords with TinyLlama and match via TF-IDF."
)

if __name__ == "__main__":
    ui.launch()
