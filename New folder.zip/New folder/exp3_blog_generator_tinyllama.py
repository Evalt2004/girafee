# exp3_blog_generator_tinyllama.py
# Ultra-simple local blog generator using TinyLlama + Gradio

import gradio as gr
import ollama

def generate_blog(topic, tone, length, outline):
    prompt = (
        f"Write a blog post about '{topic}' in a {tone} tone.\n"
        f"Target length: about {length} words.\n"
        f"Outline:\n{outline}\n"
        "Keep it clear, structured, and engaging."
    )
    try:
        r = ollama.generate(model="tinyllama", prompt=prompt)
        return r["response"].strip()
    except Exception as e:
        return f"Error: {e}"

gr.Interface(
    fn=generate_blog,
    inputs=[
        gr.Textbox(label="Topic", placeholder="Role of AI in Education"),
        gr.Dropdown(["Informative","Conversational","Formal","Casual"], value="Informative", label="Tone"),
        gr.Textbox(label="Length (words)", value="300"),
        gr.Textbox(label="Outline", lines=4, placeholder="Intro\nMain Points\nConclusion"),
    ],
    outputs="text",
    title="TinyLlama Blog Generator",
    description="Creates blog posts locally using TinyLlama via Ollama."
).launch()
