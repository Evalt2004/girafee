# exp6_document_analyzer_tinyllama.py

# 11-09-2025

import gradio as gr
import os
import json
from PyPDF2 import PdfReader
from docx import Document
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import ollama

print("URK22CS1200")

# ---------------- STEP 1: Extract Text ----------------
def extract_text(file):
    filename = file.name
    text = ""
    if filename.endswith(".pdf"):
        reader = PdfReader(filename)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    elif filename.endswith(".docx"):
        doc = Document(filename)
        text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
    elif filename.endswith(".txt"):
        text = file.read().decode("utf-8")
    else:
        return "Unsupported file type."
    return text.strip()

# ---------------- STEP 2: Generate with TinyLlama ----------------
def tinyllama_generate(prompt, max_tokens=800):
    try:
        response = ollama.generate(model="tinyllama", prompt=prompt)
        return response.get("response", "").strip()
    except Exception as e:
        return f"Error: {e}"

# ---------------- STEP 3: Analyze Document ----------------
def analyze_document(file, summary_level, user_question):
    text = extract_text(file)
    if not text or text.startswith("Unsupported"):
        return "Could not extract text.", "", ""

    if summary_level == "Short":
        instruction = "Summarize this document in 1–2 sentences capturing the main idea."
    elif summary_level == "Medium":
        instruction = "Summarize this document in one paragraph highlighting all key points."
    else:
        instruction = (
            "Provide a detailed, section-wise summary with headings and key points. "
            "For legal texts, include Payment Terms, Liabilities, Termination. "
            "For literary texts, include Characters, Themes, and Moral."
        )

    summary_prompt = f"{instruction}\n\nDocument:\n{text[:5000]}"
    summary = tinyllama_generate(summary_prompt)

    qa = ""
    if user_question and user_question.strip():
        qa_prompt = f"Answer this question based only on the following text:\n{text[:5000]}\n\nQuestion: {user_question}"
        qa = tinyllama_generate(qa_prompt, max_tokens=400)

    key_prompt = (
        "List the key clauses, keywords, or themes from the following text:\n"
        f"{text[:4000]}"
    )
    keywords = tinyllama_generate(key_prompt, max_tokens=400)

    return summary, qa, keywords

# ---------------- STEP 4: Export Results ----------------
def export_content(summary, qa, keywords, format_type):
    output_path = f"analyzed_output.{format_type}"
    if format_type == "pdf":
        c = canvas.Canvas(output_path, pagesize=letter)
        c.drawString(72, 750, "AI Document Analysis Report")
        c.setFont("Helvetica", 10)
        y = 720
        for section, content in [
            ("Summary", summary),
            ("Q&A", qa),
            ("Keywords / Clauses", keywords),
        ]:
            c.drawString(72, y, f"{section}:")
            y -= 15
            for line in content.split("\n"):
                c.drawString(80, y, line[:100])
                y -= 12
                if y < 72:
                    c.showPage()
                    y = 750
        c.save()
    elif format_type == "docx":
        doc = Document()
        doc.add_heading("AI Document Analysis", 0)
        doc.add_heading("Summary", level=1)
        doc.add_paragraph(summary)
        doc.add_heading("Q&A", level=1)
        doc.add_paragraph(qa)
        doc.add_heading("Keywords / Clauses", level=1)
        doc.add_paragraph(keywords)
        doc.save(output_path)
    else:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(f"SUMMARY:\n{summary}\n\nQ&A:\n{qa}\n\nKEYWORDS:\n{keywords}")

    return f"Exported successfully as {output_path}"

# ---------------- STEP 5: UI ----------------
def main_ui():
    with gr.Blocks(theme=gr.themes.Soft()) as demo:
        gr.Markdown("# 📘 AI Document Analyzer: Summarize, Query, Export (TinyLlama)")
        gr.Markdown("Upload a PDF, DOCX, or TXT file for summarization, Q&A, and export options.")

        with gr.Tab("Upload & Analyze"):
            file_input = gr.File(file_types=[".pdf", ".docx", ".txt"], label="Upload Document")
            summary_level = gr.Radio(["Short", "Medium", "Detailed"], value="Medium", label="Summary Level")
            user_question = gr.Textbox(lines=2, placeholder="Optional: Ask a question about the document")
            analyze_button = gr.Button("Analyze Document")

        with gr.Tab("Summary"):
            summary_output = gr.Textbox(label="Generated Summary", lines=10)
        with gr.Tab("Q&A"):
            qa_output = gr.Textbox(label="Answer", lines=6)
        with gr.Tab("Keywords / Clauses"):
            keyword_output = gr.Textbox(label="Extracted Keywords or Clauses", lines=8)
        with gr.Tab("Export & Reporting"):
            export_format = gr.Radio(["pdf", "docx", "txt"], label="Export Format", value="pdf")
            export_button = gr.Button("Export")
            export_message = gr.Textbox(label="Export Status")

        analyze_button.click(
            fn=analyze_document,
            inputs=[file_input, summary_level, user_question],
            outputs=[summary_output, qa_output, keyword_output],
        )

        export_button.click(
            fn=export_content,
            inputs=[summary_output, qa_output, keyword_output, export_format],
            outputs=export_message,
        )

    demo.launch()

if __name__ == "__main__":
    main_ui()
