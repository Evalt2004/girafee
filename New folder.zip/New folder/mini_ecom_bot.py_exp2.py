# mini_ecom_bot.py
# Smallest working chatbot: FAQ via TF-IDF + TinyLlama fallback

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import ollama

# ---- Load data ----
faq = pd.read_csv("faq.csv")  # columns: q, a

# ---- Build TF-IDF on questions ----
vec = TfidfVectorizer(stop_words="english")
faq_tfidf = vec.fit_transform(faq["q"].astype(str))

def best_faq_answer(query, threshold=0.35):
    q_vec = vec.transform([query])
    sims = cosine_similarity(q_vec, faq_tfidf).ravel()
    i = sims.argmax()
    if sims[i] >= threshold:
        return faq.iloc[i]["a"]
    return None

def tinyllama_fallback(query):
    prompt = (
        "You are a concise e-commerce FAQ assistant. "
        "Answer briefly and helpfully.\n\nUser query: " + query
    )
    try:
        r = ollama.generate(model="tinyllama", prompt=prompt)
        return r["response"].strip()
    except Exception as e:
        return f"(LLM fallback unavailable: {e})"

print("E-Commerce FAQ Bot\nType 'exit' to quit.\n")

while True:
    user = input("You: ").strip()
    if user.lower() == "exit":
        print("Bye")
        break
    ans = best_faq_answer(user)
    if ans:
        print("Bot:", ans)
    else:
        print("Bot:", tinyllama_fallback(user))
    print("-" * 50)
