# exp4_email_assistant_tinyllama.py
# Simple intelligent email assistant using TinyLlama (via Ollama)

import ollama

# Step 2: Past examples
past_examples = [
    {"customer": "My order arrived damaged.", "agent": "I'm really sorry to hear that. I can arrange a replacement or a full refund immediately."},
    {"customer": "The delivery is delayed again!", "agent": "Apologies for the delay. I’ve escalated this to our logistics team and will update you shortly."},
    {"customer": "I received the wrong item.", "agent": "I apologize for the mix-up. Could you please share a photo of the item you received so we can correct it quickly?"},
]

# Step 3: Build prompt
def build_prompt(new_query: str) -> str:
    examples_text = "\n\n".join(
        f"Customer: {ex['customer']}\nAgent: {ex['agent']}" for ex in past_examples
    )
    prompt = f"""
You are a polite and professional customer support assistant.
Here are some past conversations:
{examples_text}

Now, draft a helpful reply to the NEW customer message:
Customer: {new_query}
Reply:
"""
    return prompt.strip()

# Step 4–5: Generate suggested reply
def suggest_reply(new_query: str) -> str:
    prompt = build_prompt(new_query)
    response = ollama.chat(
        model="tinyllama",
        messages=[
            {"role": "system", "content": "You are a helpful customer support assistant."},
            {"role": "user", "content": prompt},
        ],
    )
    return response["message"]["content"].strip()

# Step 6: Run
print("📧 Intelligent Email Assistant (TinyLlama)\nType 'exit' to quit.\n")

while True:
    query = input("Customer: ")
    if query.lower() == "exit":
        print("Goodbye 👋")
        break
    reply = suggest_reply(query)
    print("\nSuggested Reply:\n", reply)
    print("-" * 60)
