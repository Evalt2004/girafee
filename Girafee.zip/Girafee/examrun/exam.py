import requests
import csv
import gradio as gr

OLLAMA_URL = "http://localhost:11434/api/generate"
model = "mistral:latest"

# Load CSV
csv_text = ""
with open("data.csv", "r", encoding="utf-8") as f:
    for row in csv.reader(f):
        csv_text += ", ".join(row) + "\n"

def ask_llm(prompt):
    try:
        final_prompt = f"Here is the CSV data:\n{csv_text}\n\nUser question: {prompt}"

        response = requests.post(OLLAMA_URL, json={
            "model": model,
            "prompt": final_prompt,
            "stream": False
        })

        data = response.json()
        return data.get("response", "(no response)")

    except Exception as e:
        return f"Error connecting to model: {e}"

gr.Interface(
    fn=ask_llm,
    inputs="text",
    outputs="text",
    title="CSV + LLM Viewer"
).launch()
































# import requests
# import csv

# OLLAMA_URL = "http://localhost:11434/api/generate"
# model = "mistral:latest"

# # Read CSV into a text string
# csv_text = ""
# with open("data.csv", "r", encoding="utf-8") as f:
#     reader = csv.reader(f)
#     for row in reader:
#         csv_text += ", ".join(row) + "\n"

# while True:
#     prompt = input("\nEnter your query (or type exit): ")

#     if prompt.lower() == "exit":
#         print("Goodbye.")
#         break

#     final_prompt = f"Here is the CSV data:\n{csv_text}\n\nUser question: {prompt}"

#     payload = {
#         "model": model,
#         "prompt": final_prompt,
#         "stream": False
#     }

#     try:
#         response = requests.post(OLLAMA_URL, json=payload)
#         data = response.json()
#         print("\nResponse:\n")
#         print(data.get("response", "(no response)"))
#     except Exception as e:
#         print("Error:", e)


































# import requests

# OLLAMA_URL = "http://localhost:11434/api/generate"

# model = "mistral:latest"

# while True:
#     prompt = input("\nEnter your query (or type exit): ")

#     if prompt.lower() == "exit":
#         print("Goodbye.")
#         break

#     payload = {
#         "model": model,
#         "prompt": prompt,
#         "stream": False
#     }

#     try:
#         response = requests.post(OLLAMA_URL, json=payload)
#         data = response.json()
#         print("\nResponse:\n")
#         print(data.get("response", "(no response)"))

#     except Exception as e:
#         print("Error:", e)
        
        
        
        
        
        
# ollama serve
# ollama list
# # ollama run mistral:latest
# ollama serve
# ollama list
# ollama run model-name
# python app.py